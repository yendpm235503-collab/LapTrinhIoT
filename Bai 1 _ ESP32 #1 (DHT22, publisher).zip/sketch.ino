#include <WiFi.h>
#include <PubSubClient.h>
#include <DHT.h>

#define DHTPIN  27
#define DHTTYPE DHT22

const char* ssid        = "Wokwi-GUEST";
const char* password    = "";
const char* mqtt_server = "broker.hivemq.com";   // HiveMQ public broker
const int   mqtt_port   = 1883;
const char* TOPIC_TEMP  = "Buoi4/bai1/nhietdo";  // doi ten cho rieng cua ban

WiFiClient espClient;
PubSubClient client(espClient);
DHT dht(DHTPIN, DHTTYPE);
unsigned long lastMsg = 0;

void setup_wifi() {
  Serial.print("Ket noi WiFi");
  WiFi.begin(ssid, password, 6);
  while (WiFi.status() != WL_CONNECTED) { delay(300); Serial.print("."); }
  Serial.println(" OK");
}

void reconnect() {
  while (!client.connected()) {
    String id = "esp32-pub-" + String(random(0xffff), HEX);
    Serial.print("Ket noi HiveMQ... ");
    if (client.connect(id.c_str())) Serial.println("OK");
    else { Serial.print("loi rc="); Serial.println(client.state()); delay(2000); }
  }
}

void setup() {
  Serial.begin(115200);
  dht.begin();
  setup_wifi();
  client.setServer(mqtt_server, mqtt_port);
}

void loop() {
  if (!client.connected()) reconnect();
  client.loop();

  if (millis() - lastMsg > 2000) {
    lastMsg = millis();
    float t = dht.readTemperature();
    if (isnan(t)) { Serial.println("Loi doc DHT22"); return; }
    char buf[10];
    dtostrf(t, 4, 1, buf);
    client.publish(TOPIC_TEMP, buf);
    Serial.print("Gui nhiet do: "); Serial.println(buf);
  }
}