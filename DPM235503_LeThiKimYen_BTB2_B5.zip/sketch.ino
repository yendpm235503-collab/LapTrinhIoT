// --- Khai báo các chân cắm ---
const int GAS_AO_PIN = A0;   // Chân đọc Analog từ cảm biến gas
const int BUZZER_POS = 8;    // Chân dương còi báo
const int BUZZER_NEG = 9;    // Chân âm còi báo

// Ngưỡng cảnh báo (đặt mức 100 để dễ thử nghiệm)
const int GAS_THRESHOLD = 100; 

void setup() {
  Serial.begin(9600);

  // Cấu hình chân còi
  pinMode(BUZZER_POS, OUTPUT);
  pinMode(BUZZER_NEG, OUTPUT);

  // Ép chân 9 xuống mức LOW làm chân GND cho Còi
  digitalWrite(BUZZER_NEG, LOW);

  noTone(BUZZER_POS);

  Serial.println(F("--- Hệ thống kiểm tra khí Gas ---"));
}

void loop() {
  // Đọc giá trị Analog từ cảm biến
  int gasValue = analogRead(GAS_AO_PIN);

  // In giá trị ra Serial Monitor
  Serial.print(F("Giá trị Gas: "));
  Serial.print(gasValue);

  // Kiểm tra ngưỡng phát còi
  if (gasValue > GAS_THRESHOLD) {
    Serial.println(F(" -> ⚠️ CẢNH BÁO: RÒ RỈ GAS! (CÒI KÊU)"));
    tone(BUZZER_POS, 1000); // Tần số còi 1000 Hz
  } else {
    Serial.println(F(" -> An toàn"));
    noTone(BUZZER_POS);     // Tắt còi
  }

  delay(300);
}