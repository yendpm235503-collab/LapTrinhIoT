#include <WiFi.h>
#include <PubSubClient.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>

// --- ĐỊNH NGHĨA CHÂN GPIO ---
#define PIR_PIN       13
#define LDR_PIN       34
#define RELAY_PIN     12
#define BUZZER_PIN    14

// --- CẤU HÌNH THÔNG SỐ ---
const int LIGHT_THRESHOLD      = 2000;  // Ngưỡng ánh sáng (ADC 0-4095)
const unsigned long TIMEOUT_MS = 10000; // Thời gian chờ tắt đèn (10 giây)

// --- THÔNG TIN WI-FI & MQTT (WOKWI GUEST) ---
const char* WIFI_SSID   = "Wokwi-GUEST";
const char* WIFI_PASS   = "";
const char* MQTT_SERVER = "broker.hivemq.com"; // Broker MQTT công cộng
const int   MQTT_PORT   = 1883;

// Topics MQTT
const char* TOPIC_STATE = "esp32_smartlight/light/state";
const char* TOPIC_MODE  = "esp32_smartlight/mode/state";
const char* TOPIC_CMD   = "esp32_smartlight/light/command";

// --- KHỞI TẠO ĐỐI TƯỢNG ---
LiquidCrystal_I2C lcd(0x27, 16, 2);
WiFiClient espClient;
PubSubClient mqttClient(espClient);

// --- BIẾN TOÀN CỤC ---
bool isAutoMode              = true;
bool isLightOn               = false;
unsigned long lastMotionTime = 0;

void playBuzzer() {
  digitalWrite(BUZZER_PIN, HIGH);
  delay(100);
  digitalWrite(BUZZER_PIN, LOW);
}

void updateLCD(int ldrVal) {
  lcd.setCursor(0, 0);
  lcd.print("Mode: ");
  lcd.print(isAutoMode ? "AUTO  " : "MANUAL");
  
  lcd.setCursor(0, 1);
  lcd.print("Light:");
  lcd.print(isLightOn ? "ON " : "OFF");
  lcd.print(" LDR:");
  lcd.print(ldrVal);
  lcd.print("   ");
}

void callback(char* topic, byte* payload, unsigned int length) {
  String message;
  for (int i = 0; i < length; i++) message += (char)payload[i];

  if (message == "AUTO") {
    isAutoMode = true;
    mqttClient.publish(TOPIC_MODE, "AUTO");
  } else if (message == "ON") {
    isAutoMode = false;
    isLightOn = true;
    digitalWrite(RELAY_PIN, HIGH);
    mqttClient.publish(TOPIC_STATE, "ON");
    mqttClient.publish(TOPIC_MODE, "MANUAL");
    playBuzzer();
  } else if (message == "OFF") {
    isAutoMode = false;
    isLightOn = false;
    digitalWrite(RELAY_PIN, LOW);
    mqttClient.publish(TOPIC_STATE, "OFF");
    mqttClient.publish(TOPIC_MODE, "MANUAL");
    playBuzzer();
  }
}

void reconnectMQTT() {
  while (!mqttClient.connected()) {
    String clientId = "ESP32Client-" + String(random(0xffff), HEX);
    if (mqttClient.connect(clientId.c_str())) {
      mqttClient.subscribe(TOPIC_CMD);
      mqttClient.publish(TOPIC_MODE, isAutoMode ? "AUTO" : "MANUAL");
    } else {
      delay(2000);
    }
  }
}

void setup() {
  Serial.begin(115200);
  pinMode(PIR_PIN, INPUT);
  pinMode(LDR_PIN, INPUT);
  pinMode(RELAY_PIN, OUTPUT);
  pinMode(BUZZER_PIN, OUTPUT);

  digitalWrite(RELAY_PIN, LOW);
  digitalWrite(BUZZER_PIN, LOW);

  lcd.init();
  lcd.backlight();
  lcd.print("IoT Smart Light");
  lcd.setCursor(0, 1);
  lcd.print("Connecting...  ");

  WiFi.begin(WIFI_SSID, WIFI_PASS);
  while (WiFi.status() != WL_CONNECTED) delay(500);

  mqttClient.setServer(MQTT_SERVER, MQTT_PORT);
  mqttClient.setCallback(callback);
}

void loop() {
  if (!mqttClient.connected()) reconnectMQTT();
  mqttClient.loop();

  int motionState = digitalRead(PIR_PIN);
  int ldrValue    = analogRead(LDR_PIN);

  // Xử lý ở chế độ AUTO
  if (isAutoMode) {
    if (motionState == HIGH && ldrValue < LIGHT_THRESHOLD) {
      lastMotionTime = millis();
      if (!isLightOn) {
        isLightOn = true;
        digitalWrite(RELAY_PIN, HIGH);
        mqttClient.publish(TOPIC_STATE, "ON");
        playBuzzer();
      }
    }
    if (isLightOn && (millis() - lastMotionTime > TIMEOUT_MS)) {
      isLightOn = false;
      digitalWrite(RELAY_PIN, LOW);
      mqttClient.publish(TOPIC_STATE, "OFF");
      playBuzzer();
    }
  }

  updateLCD(ldrValue);
  delay(200);
}