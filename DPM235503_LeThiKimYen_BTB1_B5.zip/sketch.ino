// --- Khai báo các chân cắm ---
const int LED_PIN = 9;       // Chân điều khiển LED (PWM)
const int BUTTON_1 = 3;      // Chân Nút nhấn 1 (Nút phía trên)
const int BUTTON_2 = 2;      // Chân Nút nhấn 2 (Nút phía dưới)
const int POT_PIN = A0;      // Chân đọc tín hiệu Biến trở

// --- Biến lưu trạng thái hệ thống ---
bool ledStatus = true;       // Trạng thái bật/tắt của LED (Mặc định: BẬT)

void setup() {
  // Khởi tạo cổng Serial để giám sát dữ liệu
  Serial.begin(9600);

  // Cấu hình chân xuất/nhập tín hiệu
  pinMode(LED_PIN, OUTPUT);
  pinMode(BUTTON_1, INPUT_PULLUP); // Điện trở kéo lên nội bộ
  pinMode(BUTTON_2, INPUT_PULLUP);
}

void loop() {
  // 1. Đọc giá trị từ biến trở (Dải giá trị: 0 - 1023)
  int potValue = analogRead(POT_PIN);
  
  // Chuyển đổi giá trị biến trở sang dải độ sáng PWM (0 - 255)
  int brightness = map(potValue, 0, 1023, 0, 255);

  // 2. Đọc trạng thái nút nhấn (LOW khi nút được nhấn)
  int btn1State = digitalRead(BUTTON_1);
  int btn2State = digitalRead(BUTTON_2);

  // Nút 1 (Chân 3): Bật đèn
  if (btn1State == LOW) {
    ledStatus = true;
    delay(50); // Khử rung nút nhấn (Debounce)
  }

  // Nút 2 (Chân 2): Tắt đèn
  if (btn2State == LOW) {
    ledStatus = false;
    delay(50); // Khử rung nút nhấn (Debounce)
  }

  // 3. Điều khiển đèn LED
  if (ledStatus) {
    analogWrite(LED_PIN, brightness); // Cấp độ sáng theo biến trở
  } else {
    analogWrite(LED_PIN, 0);          // Tắt LED
  }

  // 4. Xuất dữ liệu ra Serial Monitor
  Serial.print("Giá trị biến trở: ");
  Serial.print(potValue);
  Serial.print(" | Độ sáng PWM: ");
  Serial.print(ledStatus ? brightness : 0);
  Serial.print(" | Trạng thái LED: ");
  Serial.println(ledStatus ? "ON" : "OFF");

  delay(100);
}