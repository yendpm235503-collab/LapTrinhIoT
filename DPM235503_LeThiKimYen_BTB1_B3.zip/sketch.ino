const int pinButton = 2; // Nút nhấn nối chân 2
const int pinLed = 9;    // LED nối chân 9

void setup() {
  pinMode(pinButton, INPUT_PULLUP); // Kích hoạt điện trở kéo lên nội bộ
  pinMode(pinLed, OUTPUT);          // Cấu hình chân 9 làm ngõ ra cho LED
}

void loop() {
  // Khi nhấn nút, chân 2 nối về GND (mức LOW) -> Bật LED
  if (digitalRead(pinButton) == LOW) {
    digitalWrite(pinLed, HIGH); // Bật LED
  } else {
    digitalWrite(pinLed, LOW);  // Tắt LED
  }
}