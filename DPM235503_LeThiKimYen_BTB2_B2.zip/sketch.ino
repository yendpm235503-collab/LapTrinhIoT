// --- Khai báo chân kết nối ---
const int PIR_PIN = 2; // Chân tín hiệu của cảm biến PIR nối vào chân Digital 2

void setup() {
  // Khởi tạo cổng Serial để giám sát dữ liệu
  Serial.begin(9600);
  
  // Cấu hình chân cảm biến là đầu vào (INPUT)
  pinMode(PIR_PIN, INPUT);

  Serial.println(F("--- Hệ thống phát hiện chuyển động PIR ---"));
  Serial.println(F("Đang khởi động cảm biến (chờ ổn định)..."));
  delay(5000); // Chờ cảm biến PIR ổn định trạng thái ban đầu
  Serial.println(F("Hệ thống đã sẵn sàng!"));
}

void loop() {
  // Đọc trạng thái từ cảm biến PIR (HIGH = Có chuyển động, LOW = Không có)
  int motionState = digitalRead(PIR_PIN);

  if (motionState == HIGH) {
    Serial.println(F("⚠️ CẢNH BÁO: Phát hiện có chuyển động!"));
  } else {
    Serial.println(F("... Không có chuyển động."));
  }

  delay(500); // Đọc lại dữ liệu sau mỗi 0.5 giây
}