const int kPinButton1 = 2; // Nút 1: Giảm độ sáng
const int kPinButton2 = 3; // Nút 2: Tăng độ sáng
const int kPinLed = 9;     // Chân xuất PWM cho LED

int ledBrightness = 128;   // Ban đầu LED sáng 50%

void setup() {
  pinMode(kPinButton1, INPUT_PULLUP);
  pinMode(kPinButton2, INPUT_PULLUP);
  pinMode(kPinLed, OUTPUT);
}

void loop() {
  // Nút Red (chân 2): Giảm độ sáng
  if (digitalRead(kPinButton1) == LOW) {
    ledBrightness--;
  } 
  // Nút Green (chân 3): Tăng độ sáng
  else if (digitalRead(kPinButton2) == LOW) {
    ledBrightness++;
  }

  // Giới hạn giá trị trong khoảng 0 đến 255
  ledBrightness = constrain(ledBrightness, 0, 255);

  // Xuất độ sáng ra LED
  analogWrite(kPinLed, ledBrightness);
  delay(20);
}