#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include "DHT.h"

#define DHTPIN     15
#define DHTTYPE    DHT22
#define BUZZER_PIN 4   // Chân GPIO 4 điều khiển Còi báo

#define TEMP_THRESHOLD 30.0 // Ngưỡng nhiệt độ cảnh báo (30°C)

DHT dht(DHTPIN, DHTTYPE);
LiquidCrystal_I2C lcd(0x27, 16, 2);

void setup() {
  Serial.begin(115200);

  pinMode(BUZZER_PIN, OUTPUT);
  digitalWrite(BUZZER_PIN, LOW); // Tắt còi ban đầu

  lcd.init();
  lcd.backlight();
  lcd.setCursor(0, 0);
  lcd.print("He thong Canh bao");
  
  dht.begin();
  delay(2000);
  lcd.clear();

  Serial.println("=== CHUONG 7: BAI 9 - DHT22 KET HOP BUZZER & LCD ===");
}

void loop() {
  float h = dht.readHumidity();
  float t = dht.readTemperature();

  if (isnan(h) || isnan(t)) {
    lcd.setCursor(0, 0);
    lcd.print("Loi cam bien!   ");
    return;
  }

  // Hiển thị Nhiệt độ & Độ ẩm lên LCD
  lcd.setCursor(0, 0);
  lcd.print("Temp: ");
  lcd.print(t, 1);
  lcd.print((char)223);
  lcd.print("C  ");

  // Kiểm tra ngưỡng nhiệt độ để kích hoạt cảnh báo
  if (t >= TEMP_THRESHOLD) {
    // Dòng 2 LCD báo CANH BAO
    lcd.setCursor(0, 1);
    lcd.print("ALARM: OVERTEMP!");
    
    // Phát tiếng còi tít tít
    digitalWrite(BUZZER_PIN, HIGH);
    delay(200);
    digitalWrite(BUZZER_PIN, LOW);
    
    Serial.print("[CANH BAO] Nhiet do cao: ");
  } else {
    // Dòng 2 LCD hiện độ ẩm bình thường
    lcd.setCursor(0, 1);
    lcd.print("Humid: ");
    lcd.print(h, 1);
    lcd.print(" %   ");

    digitalWrite(BUZZER_PIN, LOW); // Tắt còi
    Serial.print("[BINH THUONG] Nhiet do: ");
  }

  Serial.print(t);
  Serial.print(" *C  |  Do am: ");
  Serial.print(h);
  Serial.println(" %");

  delay(1500); // Tần số cập nhật
}