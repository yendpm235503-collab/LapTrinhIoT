// --- Khai báo chân kết nối ---
const int FLAME_DO_PIN = 8;  // Chân đọc tín hiệu Digital (DO)
const int FLAME_AO_PIN = A0; // Chân đọc tín hiệu Analog (AO)

void setup() {
  // Khởi tạo giao tiếp Serial
  Serial.begin(9600);
  
  // Cấu hình chân Digital làm ngõ vào
  pinMode(FLAME_DO_PIN, INPUT);

  Serial.println(F("--- Hệ thống giám sát cảm biến lửa ---"));
}

void loop() {
  // 1. Đọc giá trị Analog (từ 0 đến 1023)
  // Giá trị càng nhỏ thể hiện cường độ lửa/ánh sáng hồng ngoại càng mạnh
  int analogValue = analogRead(FLAME_AO_PIN);

  // 2. Đọc giá trị Digital (HIGH hoặc LOW)
  // Tín hiệu LOW khi phát hiện lửa vượt ngưỡng cài đặt trên biến trở
  int digitalValue = digitalRead(FLAME_DO_PIN);

  // 3. Xuất dữ liệu ra Serial Monitor
  Serial.print(F("Giá trị Analog (A0): "));
  Serial.print(analogValue);
  Serial.print(F(" | Tín hiệu Digital (D8): "));

  if (digitalValue == LOW) {
    Serial.println(F("🔥 CẢNH BÁO: Phát hiện có LỬA!"));
  } else {
    Serial.println(F("OK (An toàn)"));
  }

  delay(500); // Cập nhật dữ liệu mỗi 0.5 giây
}