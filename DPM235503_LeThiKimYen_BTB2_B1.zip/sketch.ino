#include <DHT.h>

// --- Khai báo chân kết nối và loại cảm biến ---
#define DHTPIN 2       // Chân Data của DHT22 nối vào chân Digital 2
#define DHTTYPE DHT22  // Loại cảm biến là DHT22 (hoặc AM2302)

// Khởi tạo đối tượng cảm biến DHT
DHT dht(DHTPIN, DHTTYPE);

void setup() {
  // Khởi tạo giao tiếp Serial ở tốc độ 9600 baud
  Serial.begin(9600);
  Serial.println(F("--- Đang khởi động cảm biến DHT22 ---"));

  // Khởi chạy cảm biến DHT
  dht.begin();
}

void loop() {
  // DHT22 phản hồi chậm, nên chờ ít nhất 2 giây giữa các lần đọc dữ liệu
  delay(2000);

  // Đọc độ ẩm (%)
  float humidity = dht.readHumidity();
  // Đọc nhiệt độ (°C)
  float temperature = dht.readTemperature();

  // Kiểm tra xem tín hiệu đọc từ cảm biến có bị lỗi không
  if (isnan(humidity) || isnan(temperature)) {
    Serial.println(F("Lỗi: Không thể đọc dữ liệu từ cảm biến DHT22!"));
    return;
  }

  // Xuất dữ liệu ra màn hình Serial Monitor
  Serial.print(F("Độ ẩm: "));
  Serial.print(humidity);
  Serial.print(F(" %  |  "));
  Serial.print(F("Nhiệt độ: "));
  Serial.print(temperature);
  Serial.println(F(" °C"));
}