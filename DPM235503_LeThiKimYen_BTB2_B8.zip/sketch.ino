#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <DHT.h>

// Cấu hình chân kết nối DHT22
#define DHTPIN 2          // Chân Data của DHT22 nối vào chân số 2
#define DHTTYPE DHT22     // Loại cảm biến DHT22

DHT dht(DHTPIN, DHTTYPE);

// Khai báo màn hình LCD (Địa chỉ mặc định I2C thường là 0x27 hoặc 0x3F, 16 cột, 2 dòng)
LiquidCrystal_I2C lcd(0x27, 16, 2);

void setup() {
  // Khởi tạo màn hình LCD
  lcd.init();
  lcd.backlight();
  
  // Khởi tạo cảm biến DHT22
  dht.begin();

  // Hiển thị thông báo khởi động
  lcd.setCursor(0, 0);
  lcd.print("Dang khoi dong..");
  delay(2000);
  lcd.clear();
}

void loop() {
  // Đọc độ ẩm (%) và nhiệt độ (°C)
  float humidity = dht.readHumidity();
  float temperature = dht.readTemperature();

  // Kiểm tra xem việc đọc dữ liệu có bị lỗi không
  if (isnan(humidity) || isnan(temperature)) {
    lcd.setCursor(0, 0);
    lcd.print("Loi doc sensor! ");
    return;
  }

  // Hiển thị nhiệt độ lên dòng 1
  lcd.setCursor(0, 0);
  lcd.print("Nhiet do: ");
  lcd.print(temperature, 1);
  lcd.print((char)223); // Ký tự độ (°)
  lcd.print("C  ");

  // Hiển thị độ ẩm lên dòng 2
  lcd.setCursor(0, 1);
  lcd.print("Do am:    ");
  lcd.print(humidity, 1);
  lcd.print("%  ");

  // Đọc lại dữ liệu mỗi 2 giây (DHT22 cần khoảng nghỉ 2s giữa các lần đọc)
  delay(2000);
}