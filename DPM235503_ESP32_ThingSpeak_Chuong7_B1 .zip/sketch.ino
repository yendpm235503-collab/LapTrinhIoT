#include <WiFi.h>
#include <DHT.h>
#include "ThingSpeak.h"

// WiFi mặc định của Wokwi
const char* ssid = "Wokwi-GUEST";
const char* password = "";

// Thông tin ThingSpeak của bạn
unsigned long myChannelNumber = 3533840;
const char* myWriteAPIKey = "7JSI3PVAUZK8NYFS";

#define DHTPIN 4
#define DHTTYPE DHT22
DHT dht(DHTPIN, DHTTYPE);

WiFiClient client;

void setup() {
  Serial.begin(115200);
  dht.begin();

  WiFi.begin(ssid, password);
  Serial.print("Dang ket noi WiFi...");
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("\nDa ket noi WiFi!");

  ThingSpeak.begin(client);
}

void loop() {
  float h = dht.readHumidity();
  float t = dht.readTemperature();

  if (isnan(h) || isnan(t)) {
    Serial.println("Loi doc cam bien!");
    delay(2000);
    return;
  }

  Serial.print("Nhiet do: "); Serial.print(t);
  Serial.print("°C | Do am: "); Serial.print(h); Serial.println("%");

  ThingSpeak.setField(1, t);
  ThingSpeak.setField(2, h);

  int code = ThingSpeak.writeFields(myChannelNumber, myWriteAPIKey);
  if (code == 200) {
    Serial.println("-> Gui ThingSpeak thanh cong!");
  } else {
    Serial.println("-> Loi gui du lieu: " + String(code));
  }

  delay(15000);
}