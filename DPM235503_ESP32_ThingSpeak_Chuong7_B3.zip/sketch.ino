// Khai báo chân GPIO điều khiển LED
#define LED_PIN 2

void setup() {
  // Khởi tạo Serial Monitor
  Serial.begin(115200);
  
  // Cấu hình chân GPIO 2 là Output
  pinMode(LED_PIN, OUTPUT);

  Serial.println("=== CHUONG 7: BAI 3 - DIEU KHIEN LED SANG TAT ===");
}

void loop() {
  // 1. Bật đèn LED
  digitalWrite(LED_PIN, HIGH);
  Serial.println("Trang thai: LED SANG (HIGH)");
  delay(1000); // Giữ sáng trong 1 giây (1000ms)

  // 2. Tắt đèn LED
  digitalWrite(LED_PIN, LOW);
  Serial.println("Trang thai: LED TAT (LOW)");
  delay(1000); // Giữ tắt trong 1 giây
}