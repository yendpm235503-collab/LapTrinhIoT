// Khai báo chân đọc Analog (GPIO 34 thuộc bộ ADC1 trên ESP32)
#define POT_PIN 34  

void setup() {
  // Khởi tạo Serial Monitor với tốc độ 115200
  Serial.begin(115200);
  
  Serial.println("=== CHUONG 7: BAI 2 - DOC TIN HIEU ANALOG ===");
}

void loop() {
  // Đọc giá trị ADC từ biến trở (ESP32 có độ phân giải 12-bit: từ 0 đến 4095)
  int analogValue = analogRead(POT_PIN); 

  // Quy đổi giá trị ADC sang điện áp thực tế (từ 0V đến 3.3V)
  float voltage = analogValue * (3.3 / 4095.0);

  // In thông số ra Serial Monitor
  Serial.print("Gia tri ADC: ");
  Serial.print(analogValue);
  Serial.print(" \t| Điện áp: ");
  Serial.print(voltage, 2); // In lấy 2 chữ số thập phân
  Serial.println(" V");

  delay(500); // Đọc dữ liệu sau mỗi 0.5 giây
}