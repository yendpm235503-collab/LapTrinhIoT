// --- Khai báo các chân cắm ---
const int SENSOR_PIN = 2; // Chân đọc tín hiệu từ cảm biến
const int LED_PIN = 3;    // Chân điều khiển đèn LED

void setup() {
  // Khởi tạo giao tiếp Serial để theo dõi dữ liệu
  Serial.begin(9600);

  // Cấu hình chân ngõ vào / ngõ ra
  pinMode(SENSOR_PIN, INPUT);
  pinMode(LED_PIN, OUTPUT);

  // Tắt LED ban đầu
  digitalWrite(LED_PIN, LOW);

  Serial.println(F("--- Hệ thống giám sát cảm biến & Đèn LED ---"));
}

void loop() {
  // Đọc tín hiệu kỹ thuật số từ cảm biến (HIGH hoặc LOW)
  int sensorState = digitalRead(SENSOR_PIN);

  // Kiểm tra khi cảm biến được kích hoạt (Mức HIGH)
  if (sensorState == HIGH) {
    digitalWrite(LED_PIN, HIGH); // Bật đèn LED
    Serial.println(F("⚠️ Phát hiện tác động! -> BẬT LED"));
  } else {
    digitalWrite(LED_PIN, LOW);  // Tắt đèn LED
    Serial.println(F("Trạng thái bình thường. -> TẮT LED"));
  }

  delay(100); // Cập nhật trạng thái sau mỗi 0.1 giây
}