// --- Khai báo chân kết nối ---
const int SWITCH_PIN = 8; // Chân đọc tín hiệu từ công tắc gạt

void setup() {
  // Khởi tạo giao tiếp Serial với máy tính
  Serial.begin(9600);

  // Sử dụng điện trở kéo lên nội bộ (INPUT_PULLUP)
  // Giúp chân số 8 luôn ở mức HIGH khi công tắc ở vị trí hở mạch
  pinMode(SWITCH_PIN, INPUT_PULLUP);

  Serial.println(F("--- Giám sát trạng thái Công tắc gạt ---"));
}

void loop() {
  // Đọc trạng thái từ công tắc gạt
  int switchState = digitalRead(SWITCH_PIN);

  // Kiểm tra vị trí của công tắc
  if (switchState == LOW) {
    // Khi gạt sang trái: Chân 8 được nối xuống GND -> Đọc được mức LOW (0)
    Serial.println(F("Công tắc: GẠT SANG TRÁI (LOW)"));
  } else {
    // Khi gạt sang phải: Chân 8 hở mạch (nhờ INPUT_PULLUP) -> Đọc được mức HIGH (1)
    Serial.println(F("Công tắc: GẠT SANG PHẢI (HIGH)"));
  }

  delay(300); // Cập nhật trạng thái mỗi 0.3 giây
}