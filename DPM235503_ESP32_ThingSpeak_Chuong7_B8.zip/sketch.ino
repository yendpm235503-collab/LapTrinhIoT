#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include "DHT.h"

// Cấu hình chân & loại cảm biến DHT
#define DHTPIN 15
#define DHTTYPE DHT22

// Khởi tạo đối tượng DHT và LCD I2C (Địa chỉ 0x27, 16 cột, 2 dòng)
DHT dht(DHTPIN, DHTTYPE);
LiquidCrystal_I2C lcd(0x27, 16, 2);

void setup() {
  Serial.begin(115200);

  // Khởi tạo LCD
  lcd.init();
  lcd.backlight();
  lcd.setCursor(0, 0);
  lcd.print("He thong DHT22");
  lcd.setCursor(0, 1);
  lcd.print("Dang khoi tao...");

  // Khởi tạo cảm biến DHT
  dht.begin();
  delay(2000); // Đợi cảm biến ổn định
  lcd.clear();

  Serial.println("=== CHUONG 7: BAI 8 - DHT22 KET HOP LCD I2C ===");
}

void loop() {
  // Đọc dữ liệu từ DHT22
  float h = dht.readHumidity();
  float t = dht.readTemperature();

  // Kiểm tra lỗi đọc cảm biến
  if (isnan(h) || isnan(t)) {
    lcd.setCursor(0, 0);
    lcd.print("Loi cam bien!   ");
    Serial.println("Khong the doc du lieu tu DHT22!");
    delay(2000);
    return;
  }

  // Hiển thị Nhiệt độ lên Dòng 1 của LCD
  lcd.setCursor(0, 0);
  lcd.print("Temp: ");
  lcd.print(t, 1); // In 1 chữ số thập phân
  lcd.print((char)223); // Ký tự độ (°)
  lcd.print("C   ");

  // Hiển thị Độ ẩm lên Dòng 2 của LCD
  lcd.setCursor(0, 1);
  lcd.print("Humid: ");
  lcd.print(h, 1);
  lcd.print(" %   ");

  // In đồng thời ra Serial Monitor
  Serial.print("Nhiet do: ");
  Serial.print(t);
  Serial.print(" *C  |  Do am: ");
  Serial.print(h);
  Serial.println(" %");

  delay(2000); // Cập nhật lại dữ liệu sau mỗi 2 giây
}