#include "wokwi-api.h"
#include <stdlib.h>

#define RAIN_THRESHOLD 30

typedef struct {
  pin_t    pin_do;
  uint32_t rain_attr;
} chip_state_t;

static void timer_event(void *user_data) {
  chip_state_t *chip = (chip_state_t *)user_data;
  uint32_t rain = attr_read(chip->rain_attr);
  pin_write(chip->pin_do, rain >= RAIN_THRESHOLD ? HIGH : LOW);
}

void chip_init(void) {
  chip_state_t *chip = malloc(sizeof(chip_state_t));
  chip->pin_do    = pin_init("DO", OUTPUT);
  chip->rain_attr = attr_init("rain", 0);

  const timer_config_t cfg = { .callback = timer_event, .user_data = chip };
  uint32_t timer_id = timer_init(&cfg);
  timer_start(timer_id, 100000, true);   // doc moi 100 ms
}