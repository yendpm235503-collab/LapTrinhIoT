#include <ESP32Servo.h>

#define RAIN_PIN  27
#define SERVO_PIN 18
#define ANGLE_OPEN  0     // mai che thu
#define ANGLE_CLOSE 120   // mai che keo ra

Servo servo;
int currentAngle = ANGLE_OPEN;

void moveTo(int target) {
  while (currentAngle != target) {
    currentAngle += (target > currentAngle) ? 1 : -1;
    servo.write(currentAngle);
    delay(10);
  }
}

void setup() {
  Serial.begin(115200);
  pinMode(RAIN_PIN, INPUT);
  servo.attach(SERVO_PIN);
  servo.write(ANGLE_OPEN);
}

void loop() {
  bool raining = digitalRead(RAIN_PIN) == HIGH;
  if (raining && currentAngle != ANGLE_CLOSE) {
    Serial.println("CO MUA -> keo mai che");
    moveTo(ANGLE_CLOSE);
  } else if (!raining && currentAngle != ANGLE_OPEN) {
    Serial.println("HET MUA -> thu mai che");
    moveTo(ANGLE_OPEN);
  }
  delay(100);
}