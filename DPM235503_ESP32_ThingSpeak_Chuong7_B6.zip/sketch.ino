#include "DHT.h"

#define DHTPIN 15     // Chân GPIO 15 nối với chân DATA của DHT22
#define DHTTYPE DHT22 // Khai báo loại cảm biến là DHT22

DHT dht(DHTPIN, DHTTYPE);

void setup() {
  Serial.begin(115200);
  Serial.println("=== CHUONG 7: BAI 6 - DOC CAM BIEN DHT22 ===");

  dht.begin(); // Khởi tạo cảm biến DHT
}

void loop() {
  // Đợi 2 giây giữa các lần đọc (DHT22 phản hồi tối đa 0.5Hz)
  delay(2000);

  // Đọc độ ẩm (%)
  float h = dht.readHumidity();
  // Đọc nhiệt độ (°C)
  float t = dht.readTemperature();

  // Kiểm tra xem có đọc thành công từ DHT22 không
  if (isnan(h) || isnan(t)) {
    Serial.println("Loi: Khong the doc du lieu tu cam bien DHT22!");
    return;
  }

  // In kết quả ra Serial Monitor
  Serial.print("Do am: ");
  Serial.print(h);
  Serial.print("%  |  Nhiet do: ");
  Serial.print(t);
  Serial.println(" *C");
}