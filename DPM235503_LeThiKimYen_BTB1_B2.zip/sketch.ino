// --- Khai báo chân kết nối theo đúng sơ đồ ---
const int sensorPin = A0;  // Chân đọc tín hiệu từ biến trở (SIG)
const int ledPin = 9;      // Chân điều khiển đèn LED (Chân 9)

int sensorValue = 0;       // Biến lưu giá trị đọc từ biến trở (0 - 1023)

void setup() {
  // Thiết lập chân 9 làm ngõ ra (OUTPUT)
  pinMode(ledPin, OUTPUT);
}

void loop() {
  // 1. Đọc giá trị tương tự từ biến trở (trả về khoảng từ 0 đến 1023)
  sensorValue = analogRead(sensorPin);

  // 2. Bật đèn LED
  digitalWrite(ledPin, HIGH);
  // Chờ khoảng thời gian (tính bằng mili-giây) theo giá trị biến trở
  delay(sensorValue);

  // 3. Tắt đèn LED
  digitalWrite(ledPin, LOW);
  // Chờ khoảng thời gian tương ứng
  delay(sensorValue);
}