// Khai báo chân GPIO kết nối LED
#define LED_PIN 2

// Cấu hình thông số PWM cho ESP32
#define PWM_FREQ     5000  // Tần số 5kHz
#define PWM_CHANNEL  0     // Kênh PWM 0
#define PWM_RESOLUTION 8   // Độ phân giải 8-bit (Giá trị từ 0 đến 255)

void setup() {
  Serial.begin(115200);
  
  // Cấu hình kênh PWM trên ESP32
  ledcSetup(PWM_CHANNEL, PWM_FREQ, PWM_RESOLUTION);
  // Gán kênh PWM vào chân GPIO 2
  ledcAttachPin(LED_PIN, PWM_CHANNEL);

  Serial.println("=== CHUONG 7: BAI 4 - DIEU KHIEN DO SANG LED (PWM) ===");
}

void loop() {
  // 1. Tăng độ sáng từ từ (tối -> sáng nhất)
  Serial.println("-> Dang TANG do sang LED...");
  for (int dutyCycle = 0; dutyCycle <= 255; dutyCycle += 5) {
    ledcWrite(PWM_CHANNEL, dutyCycle);
    delay(30); // Tạm dừng nhỏ để thấy rõ hiệu ứng tăng độ sáng
  }

  delay(500); // Giữ ở mức sáng nhất 0.5s

  // 2. Giảm độ sáng từ từ (sáng nhất -> tối)
  Serial.println("-> Dang GIAM do sang LED...");
  for (int dutyCycle = 255; dutyCycle >= 0; dutyCycle -= 5) {
    ledcWrite(PWM_CHANNEL, dutyCycle);
    delay(30); // Tạm dừng nhỏ để thấy rõ hiệu ứng giảm độ sáng
  }

  delay(500); // Giữ ở mức tối hẳn 0.5s
}