#include <LiquidCrystal_I2C.h>

// Địa chỉ I2C phổ biến của LCD1602 là 0x27, 16 cột và 2 dòng
LiquidCrystal_I2C lcd(0x27, 16, 2);

void setup() {
  Serial.begin(115200);

  // Khởi tạo màn hình LCD
  lcd.init();
  lcd.backlight(); // Bật đèn nền LCD

  // In dòng 1
  lcd.setCursor(0, 0); // Cột 0, Dòng 0
  lcd.print("CHUONG 7 - BAI 7");

  // In dòng 2
  lcd.setCursor(0, 1); // Cột 0, Dòng 1
  lcd.print("ESP32 LCD I2C");

  Serial.println("=== CHUONG 7: BAI 7 - HIEN THI LCD I2C ===");
}

void loop() {
  // Hiệu ứng nhấp nháy chữ trên dòng 2
  lcd.setCursor(0, 1);
  lcd.print("ESP32 LCD I2C   ");
  delay(1000);

  lcd.setCursor(0, 1);
  lcd.print("                "); // Xóa dòng 2
  delay(500);
}