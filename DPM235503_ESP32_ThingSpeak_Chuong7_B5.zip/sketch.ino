#include <ESP32Servo.h>

#define SERVO_PIN 18  // Chân GPIO 18 kết nối chân tín hiệu Servo

Servo myServo;  // Khởi tạo đối tượng Servo

void setup() {
  Serial.begin(115200);
  
  // Gán chân điều khiển GPIO 18 cho Servo
  myServo.attach(SERVO_PIN);

  Serial.println("=== CHUONG 7: BAI 5 - DIEU KHIEN DONG CO SERVO ===");
}

void loop() {
  // 1. Quay Servo từ 0 độ đến 180 độ
  Serial.println("-> Quay Servo tu 0 den 180 do");
  for (int pos = 0; pos <= 180; pos += 10) {
    myServo.write(pos);
    delay(15); // Đợi động cơ di chuyển
  }

  delay(1000); // Giữ ở vị trí 180 độ trong 1 giây

  // 2. Quay Servo từ 180 độ về 0 độ
  Serial.println("-> Quay Servo tu 180 ve 0 do");
  for (int pos = 180; pos >= 0; pos -= 10) {
    myServo.write(pos);
    delay(15);
  }

  delay(1000); // Giữ ở vị trí 0 độ trong 1 giây
}