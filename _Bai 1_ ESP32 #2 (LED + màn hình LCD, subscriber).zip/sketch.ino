#include <WiFi.h>
#include <PubSubClient.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>

#define LED_PIN 2

const char* ssid        = "Wokwi-GUEST";
const char* password    = "";
const char* mqtt_server = "broker.hivemq.com";
const int   mqtt_port   = 1883;
const char* TOPIC_TEMP  = "Buoi4/bai1/nhietdo";  // PHAI GIONG ben publisher

WiFiClient espClient;
PubSubClient client(espClient);
LiquidCrystal_I2C lcd(0x27, 16, 2);

void showLCD(float t, bool ledOn) {
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("Nhiet do:");
  lcd.print(t, 1);
  lcd.print("C");
  lcd.setCursor(0, 1);
  lcd.print(ledOn ? "Den: SANG" : "Den: TAT");
}

void callback(char* topic, byte* payload, unsigned int length) {
  String msg;
  for (unsigned int i = 0; i < length; i++) msg += (char)payload[i];
  float t = msg.toFloat();
  bool ledOn = (t > 35.0);
  digitalWrite(LED_PIN, ledOn ? HIGH : LOW);
  showLCD(t, ledOn);
  Serial.print("Nhan: "); Serial.print(t); Serial.println(ledOn ? " -> den SANG" : " -> den TAT");
}

void setup_wifi() {
  WiFi.begin(ssid, password, 6);
  while (WiFi.status() != WL_CONNECTED) { delay(300); Serial.print("."); }
  Serial.println(" WiFi OK");
}

void reconnect() {
  while (!client.connected()) {
    String id = "esp32-sub-" + String(random(0xffff), HEX);
    if (client.connect(id.c_str())) {
      Serial.println("HiveMQ OK");
      client.subscribe(TOPIC_TEMP);
    } else delay(2000);
  }
}

void setup() {
  Serial.begin(115200);
  pinMode(LED_PIN, OUTPUT);
  lcd.init();
  lcd.backlight();
  lcd.print("Dang ket noi...");
  setup_wifi();
  client.setServer(mqtt_server, mqtt_port);
  client.setCallback(callback);
  lcd.clear();
  lcd.print("Cho du lieu...");
}

void loop() {
  if (!client.connected()) reconnect();
  client.loop();
}